

// //
// console.dir(document.body);

// ///
// console.dir(document.body.children.forest.children.tree2.children.
//     shrubbery.children.treasure);


// ///
// console.dir(document.body.childNodes[3].childNodes[3].childNodes[1].
//     childNodes[1]);

// ///combo
// console.dir(document.body.childNodes[3].childNodes[3].childNodes[1].
//     children.treasure);


//*pg228: (4)

// ///
// document.body.children.forest.children.tree2.parentElement;

// ///
// document.body.children.forest.children.tree2;

// ///
// document.body.children.forest.children.tree2.previousElementSibling;

// ///
// document.body.children.forest.children.tree1.nextElementSibling;

/////////

///*pg229
document.body.children.greeting;


///*pg 231

///
document.getElementById("two");

///pg 232
console.log(document.getElementById("two"));

///



