
//exercise 1.1//
4 + 10
14
console.log("marco");
//***********//

//exercise 1.2//
console.log("hello world");
//**************//

//exercise 1.4//
let a = 10; //asigned 10 to variable a
console.log(a);
//********//



